export async function fetchCotxes() {
	const response = await fetch("http://localhost:3000/");
	const data = await response.json();
	return data;
};

export async function createCotxe(nombre_seients, nom_vehicle,imageUrl) {
	const body = {nombre_seients: nombre_seients, nom_vehicle: nom_vehicle,imageUrl};

	const response = await fetch("http://localhost:3000/", {
		method: "POST",
		body: JSON.stringify(body),
		headers: {
			"Content-Type": "application/json"
		}
	});

	const data = await response.json();
	return data;
};
