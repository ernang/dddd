var vehicleData = {
    "vehicle1": {
        "state": "available",
        "model": "Audi Q5",
        "car_id": "0001",
        "type": "Compact SUV",
        "price": "1.2$/km",
        "year": "2015",
        "image": "../assets/vehicle1.png"
    },
    "vehicle2": {
        "state": "available",
        "model": "Mercedes GLS 450",
        "car_id": "0002",
        "type": "Intermediate",
        "price": "1.5$/km",
        "year": "2020",
        "image": "../assets/vehicle2.png"
    },
    "vehicle3": {
        "state": "available",
        "model": "Model X",
        "car_id": "0003",
        "type": "Economy",
        "price": "0.8$/km",
        "year": "2024",
        "image": "../assets/vehicle3.png"
    },
    "vehicle4": {
        "state": "unavailable",
        "model": "Ferrari 812 Superfast",
        "car_id": "0004",
        "type": "Premium",
        "price": "10$/km",
        "year": "2019",
        "image": "../assets/vehicle4.png"
    },
    "vehicle5": {
        "state": "unavailable",
        "model": "Ferrari 812 Superfast",
        "car_id": "0005",
        "type": "Premium",
        "price": "10$/km",
        "year": "2019",
        "image": "../assets/vehicle4.png"
    },
    "vehicle6": {
        "state": "available",
        "model": "Mercedes GLS 450",
        "car_id": "0006",
        "type": "Intermediate",
        "price": "1.5$/km",
        "year": "2020",
        "image": "../assets/vehicle2.png"
    },
    "vehicle7": {
        "state": "available",
        "model": "Model X",
        "car_id": "0007",
        "type": "Economy",
        "price": "0.8$/km",
        "year": "2024",
        "image": "../assets/vehicle3.png"
    },
    "vehicle8": {
        "state": "available",
        "model": "Model X",
        "car_id": "0008",
        "type": "Economy",
        "price": "0.8$/km",
        "year": "2024",
        "image": "../assets/vehicle3.png"
    },
    "vehicle9": {
        "state": "unavailable",
        "model": "Ferrari 812 Superfast",
        "car_id": "0009",
        "type": "Premium",
        "price": "10$/km",
        "year": "2019",
        "image": "../assets/vehicle4.png"
    },
};

document.getElementById("vehicle-search-input").addEventListener("input", function(e) 
{
    let modelList = [];
    console.log(e.target.value)
    for (const [key, value] of Object.entries(vehicleData)) {
        // console.log(value)
        if (value.model.includes(e.target.value)) {
            modelList.push({key, value})
        }
    }
    console.log(modelList)
    // console.log(vehicles)
    createVehicleContainer(modelList)
});

function createVehicleContainer(modelList) 
{
    // modelList is an Array of Objects.
    let container = document.getElementsByClassName("vehicle-container");
    console.log(container)
    container[0].innerHTML = ""
    for (const model of modelList) {
        var vehicle = document.createElement("div");
        vehicle.className = "vehicle";

        // Create the inner div before appending to the container
        var image = document.createElement("img");
        console.log(model)
        image.src = "./" + model.value.image;
        
        var button = document.createElement("button")
        button.className = "request-vehicle-btn"
        button.setAttribute("data-vehicle-info", model.key)
        button.type = "button"
        button.value = "Request vehicle"
        button.textContent = "Request vehicle"
        // We now append the image and the button to the vehicle div.
        vehicle.appendChild(image);
        vehicle.appendChild(button);
        
        // Then append the whole thing onto the container
        container[0].appendChild(vehicle);
    }
}

// Pels butons de Request vehicle
document.querySelectorAll('.request-vehicle-btn').forEach(function(button) {
    button.addEventListener('click', function() {
        // Obté la info del vehicle que s'ha clicat el botó
        var vehicleInfo = button.getAttribute('data-vehicle-info');
        // Crida la funció per mostrar el popup del vehicle que toca
        showVehicleInfo(vehicleInfo);
    });
});

var currentVehicleId = null;

// Pels butons de Request vehicle
document.querySelectorAll('.request-vehicle-btn').forEach(function(button) {
    button.addEventListener('click', function() {
        // Obté la info del vehicle que s'ha clicat el botó
        currentVehicleId = button.getAttribute('data-vehicle-info');
        // Crida la funció per mostrar el popup del vehicle que toca
        showVehicleInfo();
    });
});

// FUnció per obrir la finestrar popup del vehicle adient
function showVehicleInfo() {
    var info = vehicleData[currentVehicleId];
    var infoContent = `
        <img src="${info.image}" alt="${info.model}">
        <h2>${info.model}, State: ${info.state}</h2>
        <p>ID: ${info.car_id}</p>
        <p>Type: ${info.type}</p>
        <p>Price: ${info.price}</p>
        <p>Year: ${info.year}</p>
    `;
    document.getElementById('popup-window').style.display = 'block';
    document.getElementById('vehicle-info').innerHTML = infoContent;
    document.getElementById('overlay').style.display = 'block';
}

// Tanca la finestra de popup
function closePopup() {
    document.getElementById('popup-window').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('popup-request-info').style.display = 'none';
    // Reset the display of vehicle info and image when closing the popup
    var carDetails = document.querySelector('.car-info'); //Si no posem aquesta línia, quan refresquem la pàgina després
    carDetails.style.display = 'block'; //d'haver apretat el botó de request, no ens apareixerà la info del cotxe
    if (info && image) {
        info.style.display = 'block';
        image.style.display = 'block';
    }
}

function requestVehicleFunction() {
    var carDetails = document.querySelector('.car-info'); // Container for car info and buttons
    var newRequestInfo = document.getElementById('popup-request-info'); // New request form
    button.addEventListener('click', function() {
        // Toggle display of car details and new request form
        if (carDetails.style.display !== 'none') {
            carDetails.style.display = 'none'; // Hide car details
            newRequestInfo.style.display = 'block'; // Show new request form
        } else {
            carDetails.style.display = 'block'; // Show car details
            newRequestInfo.style.display = 'none'; // Hide new request form
        }
    });
}

document.getElementById('req-button').addEventListener('click', showVehicleInfo1);

document.getElementById('change-vehicle').addEventListener('click', function() {
    // Accions del botó change vehicle
    console.log('Change vehicle button clicked!');
});

// Funció per inicialitzar el mapa dins el popup
function initializeMap() {
    // Initialize your map here. This is where you would use the Google Maps API, Leaflet, or any other mapping service.
    // For example, if you're using Leaflet:
    // var map = L.map('interactive-map').setView([51.505, -0.09], 13);
    // L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    //     maxZoom: 19,
    //     attribution: '© OpenStreetMap contributors'
    // }).addTo(map);
}

// Crida a initializeMap quan el document ha carregat
document.addEventListener('DOMContentLoaded', function() {
    initializeMap();
});

function showVehicleInfo1() {
    showVehicleImage1();
    var carDetails = document.querySelector('.car-info'); // Container for car info and buttons
    var newRequestInfo = document.getElementById('popup-request-info'); // New request form
    // Toggle display of car details and new request form
    if (carDetails.style.display !== 'none') {
        carDetails.style.display = 'none'; // Hide car details
        newRequestInfo.style.display = 'block'; // Show new request form
    } else {
        carDetails.style.display = 'block'; // Show car details
        newRequestInfo.style.display = 'none'; // Hide new request form
    }
    var info = vehicleData[currentVehicleId];
    var infoContent = `
        <h2>${info.model}, State: ${info.state}</h2>
        <p>ID: ${info.car_id}</p>
    `;
    document.getElementById('vehicle-info1').innerHTML = infoContent;
}
function showVehicleImage1() {
    var info = vehicleData[currentVehicleId];
    var infoContent = `
        <img src="${info.image}" alt="${info.model}">
    `;
    document.getElementById('vehicle-image1').innerHTML = infoContent;
}