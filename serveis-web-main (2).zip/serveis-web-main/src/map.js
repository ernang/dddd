let map;
let vehicleMap;
let markers = []
const vilanovaLatLng = [41.22141647338867, 1.7298121452331543];
let userPosition
let userMarker = null
console.log("Initialized map.js")

function addMarker(latlng)
{
    console.log(`Addidng marker at ${latlng}`)
    let marker = L.marker(latlng)

    if (latlng == userPosition) {
        // userMarker is a special marker that we don't want to 
        // add to the markers list. We are interested on having
        // only one instance of userMarker in the map.
        if (userMarker != null)
            userMarker.remove()
        userMarker = marker
    }
    marker.addTo(map)
    marker.on('click', function() {
        var index = markers.indexOf(marker)
        if (index != -1) {
            markers.splice(index, 1)
        }
        marker.remove()
    });
    markers.push(marker)
}

function onMapClick(e) 
{
    console.log(`You clicked the map at ${e.latlng.toString()}`)
    addMarker(e.latlng)
    popup
      .setLatLng(e.latlng)
      .setContent(`You clicked the map at ${e.latlng.toString()}`)
      // .openOn(map);
  }

function initializeMap() {
    const map_doc = document.getElementById('main_map')
    if (map_doc != null) {
        map = L.map(map_doc).setView(vilanovaLatLng, 13);
        let tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);
        map.on('click', onMapClick);
    }
}

function initializeVehicleMap() {
    vehicleMap = L.map(document.getElementById('vehicleMap')).setView(vilanovaLatLng, 13);
    const vehicle_tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(vehicleMap);
}

document.querySelectorAll('.select-button').forEach(function(button) {
    // Buttons from the vehicle list.
    button.addEventListener('click', function() {
        if (map != null) {
            map.remove()
            map = null
        }
        if (vehicleMap == null)
            initializeVehicleMap()
    })
})

document.querySelectorAll('.request-vehicle-btn').forEach(function(button) {
    // Buttons from the highlighted vehicles in the main page.
    button.addEventListener('click', function() {
        if (map != null) {
            map.remove()
            map = null
        }
        if (vehicleMap == null)
            initializeVehicleMap()
    })
})

document.querySelectorAll("close-button").forEach(function(button) {
    // The moment we close the vehicle's popup, we want to reinitilize the general map.
    button.addEventListener('click', function() {
        initializeMap()
        if (vehicleMap != null) {
            vehicleMap.remove()
            vehicleMap = null
        }
    })
})

function userPositionSuccess(position) 
{
    // This function is called twice, for some reason. I added some logic to
    // stop adding two markers in the same map. We could figure it out, but
    // this fix will do for now.
    userPosition = [position.coords.latitude, position.coords.longitude]
    addMarker(userPosition)
    map.setView(userPosition, 13)
    L.popup().setLatLng(userPosition).setContent("You are here!").openOn(map)
}

function userPositionError() {
    console.log("Error at getting user's position")
}

const userPositionOption = {
    enableHighAccuracy: true,
    maximumAge: 3600000,        // one hour maximum until refreshing user's position
    timeout: 5000               // timeout for fetching user's position
}

const watchID = navigator.geolocation.watchPosition(userPositionSuccess, userPositionError, userPositionOption)

// const circle = L.circle([41.22141647338867, 1.7298121452331543], {
//   color: 'red',
//   fillColor: '#f03',
//   fillOpacity: 0.5,
//   radius: 500
// }).addTo(map).bindPopup('I am a circle.');

// const polygon = L.polygon([
//   [51.509, -0.08],
//   [51.503, -0.06],
//   [51.51, -0.047]
// ]).addTo(map).bindPopup('I am a polygon.');

const popup = L.popup()
  .setLatLng([41.22141647338867, 1.7298121452331543])
  .setContent('I am a standalone popup.')
  // .openOn(map);

  initializeMap();