window.addEventListener("load", () => {
    const main = document.querySelector('main'); // Asegúrate de tener un elemento <main> en tu HTML

    // Crear el contenedor del formulario
    const formBox = document.createElement('div');
    formBox.className = 'form-box';

    // Crear el formulario
    const form = document.createElement('form');
    form.className = 'form';

    // Título
    const title = document.createElement('span');
    title.className = 'title';
    title.textContent = 'Registrate';

    // Subtítulo
    const subtitle = document.createElement('span');
    subtitle.className = 'subtitle';
    subtitle.textContent = 'Inicia tu viaje con nosotros, el primero de muchos';

    // Contenedor de inputs
    const formContainer = document.createElement('div');
    formContainer.className = 'form-container';

    // Inputs
    const inputName = document.createElement('input');
    inputName.type = 'text';
    inputName.className = 'input';
    inputName.placeholder = 'Nombre';

    const inputEmail = document.createElement('input');
    inputEmail.type = 'email';
    inputEmail.className = 'input';
    inputEmail.placeholder = 'Correo electrónico';

    const inputPassword = document.createElement('input');
    inputPassword.type = 'password';
    inputPassword.className = 'input';
    inputPassword.placeholder = 'Contraseña';

    // Añadir inputs al contenedor de formulario
    formContainer.appendChild(inputName);
    formContainer.appendChild(inputEmail);
    formContainer.appendChild(inputPassword);

    // Botón de envío
    const button = document.createElement('button');
    button.textContent = 'Registrate';

    // Sección de formulario adicional
    const formSection = document.createElement('div');
    formSection.className = 'form-section';
    const formSectionParagraph = document.createElement('p');
    formSectionParagraph.textContent = 'Tienes cuenta? ';
    const loginLink = document.createElement('a');
    loginLink.href = '../form/login.html';
    loginLink.textContent = 'Iniciar Sesión';
    formSectionParagraph.appendChild(loginLink);
    formSection.appendChild(formSectionParagraph);

    // Montar todo el formulario
    form.appendChild(title);
    form.appendChild(subtitle);
    form.appendChild(formContainer);
    form.appendChild(button);
    formBox.appendChild(form);
    formBox.appendChild(formSection);

    // Añadir el formulario al main
    main.appendChild(formBox);
});
