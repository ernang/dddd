import {fetchCotxes, createCotxe} from "./api.js";

// const button = document.querySelector("#fetch-cotxes");

// button.addEventListener("click", async () => {
// 	const cotxes = await fetchCotxes();
// });

window.addEventListener("load", async () => {
    const cotxes = await fetchCotxes();
    console.log(cotxes);
    const section = document.querySelector("#cotxes");
    for (let cotxe of cotxes) {
        const div = document.createElement("div");

		const img = document.createElement("img"); // Crear un elemento img
        img.src = cotxe["imageUrl"]; // Establecer la fuente de la imagen
        img.alt = `Imagen de ${cotxe["nom_vehicle"]}`; // Texto alternativo para la imagen
        img.style.width = '100%'; // Establecer el ancho de la imagen (ajustable según necesidad)

        const p = document.createElement("p");
        p.innerText = `Asientos: ${cotxe["nombre_seients"]}`;

        const p2 = document.createElement("p");
        p2.innerText = `Nombre Vehículo: ${cotxe["nom_vehicle"]}`;

		div.appendChild(img);
        div.appendChild(p2);
        div.appendChild(p);
        section.appendChild(div);
    }
});

const form = document.querySelector("#crear-cotxe");

form.addEventListener("submit", async (event) => {
    // event.preventDefault(); 

    const nom_vehicle = event.target.elements['nom_vehicle'].value;
    const nombre_seients = parseInt(event.target.elements['nombre_seients'].value);
	const imageUrl = event.target.elements['imageUrl'].value;

    const data = await createCotxe(nombre_seients, nom_vehicle, imageUrl);

    console.log(data); 
});
