document.addEventListener('DOMContentLoaded', function() {
    var commonOptions = {
        scales: {
            y: {
                grid: {
                    color: 'rgba(255, 255, 255, 0.5)',
                },
                ticks: {
                    color: '#fff',
                }
            },
            x: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: '#fff',
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: '#fff',
                }
            }
        },
        elements: {
            line: {
                borderColor: '#fff',
                tension: 0.1
            },
            point: {
                backgroundColor: '#fff',
                borderColor: '#fff',
                borderWidth: 1,
                radius: 3
            },
            bar: {
                backgroundColor: 'rgba(255, 255, 255, 0.5)',
                borderColor: '#fff',
                borderWidth: 1
            }
        }
    };

    var monthlyReservationsChart = new Chart(document.getElementById('monthlyReservationsChart'), {
        type: 'line',
        data: {
            labels: ['Enero', 'Febrero', 'Marzo', 'Abril'],
            datasets: [{
                label: 'Reservas Mensuales',
                data: [120, 130, 150, 170],
                fill: false,
                borderColor: '#fff',
                tension: 0.1
            }]
        },
        options: commonOptions
    });

    var dailyReservationsChart = new Chart(document.getElementById('dailyReservationsChart'), {
        type: 'bar',
        data: {
            labels: ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'],
            datasets: [{
                label: 'Reservas Diarias',
                data: [50, 25, 75, 50, 100],
                backgroundColor: 'rgba(255, 255, 255, 0.5)',
                borderColor: '#fff',
                borderWidth: 1
            }]
        },
        options: commonOptions
    });

    var zonesReservationsChart = new Chart(document.getElementById('zonesReservationsChart'), {
        type: 'bar',
        data: {
            labels: ['Zona Norte', 'Zona Sur', 'Zona Este', 'Zona Oeste'],
            datasets: [{
                label: 'Zonas Mayores Reservas',
                data: [120, 150, 100, 190],
                backgroundColor: [
                    'rgba(255, 255, 255, 0.5)',
                    'rgba(255, 255, 255, 0.5)',
                    'rgba(255, 255, 255, 0.5)',
                    'rgba(255, 255, 255, 0.5)'
                ],
                borderColor: '#fff',
                borderWidth: 1
            }]
        },
        options: commonOptions
    });

    var vehicleOpinionsChart = new Chart(document.getElementById('vehicleOpinionsChart'), {
        type: 'pie',
        data: {
            labels: ['Vehículo 1', 'Vehículo 2', 'Vehículo 3'],
            datasets: [{
                data: [5, 3, 4],
                backgroundColor: [
                    'rgba(255, 205, 86, 0.5)', // amarillo más translúcido
                    'rgba(54, 162, 235, 0.5)', // azul más translúcido
                    'rgba(255, 99, 132, 0.5)' // rojo más translúcido
                ],
                borderColor: '#fff',
                borderWidth: 1
            }]
        },
        options: {
            plugins: {
                legend: {
                    labels: {
                        color: '#fff',
                    }
                }
            }
        }
    });
});
