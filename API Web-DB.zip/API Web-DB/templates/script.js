const loginForm = document.getElementById('login-form');
const loginMessage = document.getElementById('login-message');

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const email = loginForm.elements.email.value;
    const password = loginForm.elements.password.value;

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json();
            if (data.message === 'LogIn successful') {
                // Redirect to secure user dashboard page
                window.location.href = '/dashboard';
            } else {
                loginMessage.textContent = 'Something went wrong.';
            }
        } else {
            const error = await response.text();
            loginMessage.textContent = error;
        }
    } catch (error) {
        console.error('Error:', error);
        loginMessage.textContent = 'An error occurred.';
    } finally {
        loginForm.reset(); // Clear form fields after submission
    }
});
