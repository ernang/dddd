from typing import Optional, List
from pydantic import BaseModel, EmailStr


class Client(BaseModel):
    correu_electronic: str
    telefon: str
    nom: str
    data_naixement: str  # Assuming date format as string
    direccio: str
    numero_compte: str
    contrasenya: str
    username: str
    tipus_client: str


class Cotxe(BaseModel):
    nombre_seients: int


class Carrer(BaseModel):
    nom: str


class Viatge(BaseModel):
    durada_temps: int
    distancia_km: float
    preu_euros: float
    carrers: List[str]
