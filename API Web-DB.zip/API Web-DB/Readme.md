# API de Connexió amb MongoDB

Aquest projecte proporciona una API per connectar un servidor de base de dades MongoDB amb una aplicació web utilitzant FastAPI.

## Començar

### Pas 1: Crear l'arxiu principal `main.py`

Utilitza un editor de text o un IDE com Visual Studio Code per crear l'arxiu `main.py` seguint els passos detallats a la pàgina 2 de la documentació en pdf.

### Pas 2: Crear l'arxiu de documentació `docs.py`

Afegeix el codi proporcionat al nou arxiu `docs.py` per definir les metadades de les etiquetes de la teva API.

### Pas 3: Configurar la connexió a MongoDB

Crea l'arxiu `config/db.py` per establir una connexió amb la base de dades MongoDB local.

### Pas 4: Definir el model d'usuari

Dins de la carpeta `models`, crea l'arxiu `user.py` per definir la classe `User` amb els seus atributs.

### Pas 5: Establir les rutes de l'API

Defineix les operacions CRUD per als usuaris a l'arxiu `routes/user.py` utilitzant FastAPI i les eines de serialització.

### Pas 6: Definir els esquemes de dades

Utilitza la carpeta `schemas` per crear l'arxiu `user.py` que defineixi com serialitzar les dades dels usuaris.

### Pas 7: Instal·lar dependències i executar l'API.

Instal·la les dependències necessàries des de `requirements.txt` i executa l'API amb `uvicorn`.

## Dependències

Inclou una llista de totes les dependències necessàries al teu `requirements.txt`.

## Execució

Per executar l'API, utilitza la comanda:

```bash
uvicorn main:app --reload
```
Això iniciarà el servidor de l’API amb la capacitat de recarregar automàticament després de cada canvi al codi
