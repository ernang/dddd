from fastapi import FastAPI, Request
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from routes.user import user
from docs import tags_metadata

templates = Jinja2Templates(directory="templates")
app = FastAPI(title="FastAPI & Mongo CRUD",
              description="Rest API amb FastAPI i MongoDB",
              version="0.0.1",
              openapi_tags=tags_metadata)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    # Reemplaza con tu origen específico
    allow_origins=["http://127.0.0.1:8000"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE"],  # Métodos permitidos
    allow_headers=["*"],  # Encabezados permitidos
)


@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


app.include_router(user)
