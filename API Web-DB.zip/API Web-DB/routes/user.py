from fastapi import APIRouter, status, Response, HTTPException
from passlib.hash import sha256_crypt
from bson import ObjectId
from models.client import Client, Cotxe, Carrer, Viatge
from config.db import conn
from schemas.client import serializeDict, serializeList

from passlib.context import CryptContext

# Crea un objeto CryptContext con la configuración que desees
pwd_context = CryptContext(schemes=["sha256_crypt"])

router = APIRouter()

###################################
#       FUNCIONS PER CLIENTS      #
###################################


@router.get('/clients', response_model=list[Client], tags=["clients"])
async def find_all_clients():
    # Assuming 'conn' is your MongoDB client and 'client' is your collection
    return [serializeDict(client) for client in conn.local.client.find()]


@router.get('/client/{id}', response_model=Client, tags=["clients"])
async def find_one_client(id):
    return serializeDict(conn.local.client.find_one({"_id": ObjectId(id)}))


@router.post('/clients', response_model=Client, tags=["clients"])
async def create_client(client: Client):
    client_dict = dict(client)
    client_dict["contrasenya"] = pwd_context.hash(client_dict["contrasenya"])
    conn.local.client.insert_one(client_dict)
    return client


@router.put('/clients/{id}', response_model=Client, tags=["clients"])
async def update_client(id, client: Client):
    conn.local.client.find_one_and_update(
        {"_id": ObjectId(id)}, {"$set": dict(client)}
    )
    return serializeDict(conn.local.client.find_one({"_id": ObjectId(id)}))


@router.delete('/clients/{id}', status_code=status.HTTP_204_NO_CONTENT, tags=["clients"])
async def delete_client(id):
    conn.local.client.find_one_and_delete({"_id": ObjectId(id)})
    return Response(status_code=status.HTTP_204_NO_CONTENT)
# Funció que permeti realitzar un login


@router.post('/login')
async def login(user_data: Client):
    user = conn.local.client.find_one(
        {"correu_electronic": user_data.correu_electronic})
    if user:
        if pwd_context.verify(user_data.contrasenya, user["contrasenya"]):
            return {"message": "LogIn correctament realitzat"}
        else:
            raise HTTPException(
                status_code=401, detail="Contrasenya incorrecta")
    else:
        raise HTTPException(status_code=404, detail="Usuario no trobat")
