from pymongo import MongoClient
conn = MongoClient(" mongodb://admin:admin@0.0.0.0:27017")
